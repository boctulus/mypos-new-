package cl.friendlypos.mypos.model

data class DashboardItem(
    val id: Int,
    val title: String,
    val icon: Int,
    val color: Int
)