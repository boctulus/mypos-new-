package cl.friendlypos.mypos.compose.screens

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Surface
import androidx.activity.compose.setContent

import cl.friendlypos.mypos.theme.FriendlyPOSTheme

class CashPaymentActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        val totalAmount = intent.getDoubleExtra("TOTAL_AMOUNT", 0.0)
        
        setContent {
            FriendlyPOSTheme {
                Surface(color = MaterialTheme.colorScheme.background) {
                    CashPaymentScreen(
                        totalAmount = totalAmount,
                        onCancelClick = { finish() },
                        onSkipClick = { 
                            // Lógica para omitir el ingreso de efectivo
                            setResult(RESULT_OK)
                            finish()
                        },
                        onAmountEntered = { amount ->
                            // Procesar el monto ingresado
                            val intent = intent.apply {
                                putExtra("CASH_AMOUNT", amount)
                            }
                            setResult(RESULT_OK, intent)
                            finish()
                        }
                    )
                }
            }
        }
    }
}